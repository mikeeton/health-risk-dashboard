from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

import models
import schemas
from access_control import get_default_active_user_id, require_admin
from auth_utils import get_current_user, hash_password
from database import get_db
from notification_utils import create_notification, notify_role
from routes.audit import write_audit_log

router = APIRouter(
    prefix="/registration-requests",
    tags=["Registration Requests"],
)

ALLOWED_ROLES = ["doctor", "nurse", "patient"]


@router.post("/", response_model=schemas.RegistrationRequestResponse)
def create_registration_request(
    request: schemas.RegistrationRequestCreate,
    db: Session = Depends(get_db),
):
    role = request.role.lower()

    # Admin accounts are not self-service. Public access requests are limited to
    # clinical and patient roles so admin creation remains an admin-only action.
    if role not in ALLOWED_ROLES:
        raise HTTPException(
            status_code=400,
            detail="You can only request doctor, nurse, or patient access.",
        )

    if role == "patient":
        # Patient requests need enough clinical context to seed a profile after
        # approval, but no patient record is created until an admin approves.
        if request.age is None:
            raise HTTPException(
                status_code=400,
                detail="Patients must provide age.",
            )

        if not request.conditions:
            raise HTTPException(
                status_code=400,
                detail="Patients must provide at least one condition or ailment.",
            )

    existing_user = (
        db.query(models.User)
        .filter(models.User.email == request.email.lower())
        .first()
    )

    if existing_user:
        raise HTTPException(status_code=409, detail="User already exists")

    existing_request = (
        db.query(models.RegistrationRequest)
        .filter(models.RegistrationRequest.email == request.email.lower())
        .first()
    )

    if existing_request:
        raise HTTPException(
            status_code=409,
            detail="Registration request already exists",
        )

    new_request = models.RegistrationRequest(
        email=request.email.lower(),
        full_name=request.full_name.strip(),
        role=role,
        password_hash=hash_password(request.password),
        status="pending",
        created_at=datetime.now().isoformat(timespec="seconds"),
        age=request.age,
        gender=request.gender,
        conditions=request.conditions,
        medication_notes=request.medication_notes,
        lifestyle_notes=request.lifestyle_notes,
    )

    db.add(new_request)
    db.flush()

    # Notify each active admin with an individual row so unread/read state is
    # tracked per admin rather than shared across the whole role.
    notify_role(
        db,
        role="admin",
        title="New registration request",
        message=f"{new_request.full_name} requested {new_request.role} access.",
        notification_type="registration",
        link="/admin/approvals",
        related_entity="RegistrationRequest",
        related_entity_id=str(new_request.id),
    )

    db.commit()
    db.refresh(new_request)

    write_audit_log(
        db=db,
        action="CREATE_REGISTRATION_REQUEST",
        entity="RegistrationRequest",
        entity_id=str(new_request.id),
        user_email=new_request.email,
    )

    return new_request


@router.get("/", response_model=list[schemas.RegistrationRequestResponse])
def get_registration_requests(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    require_admin(current_user)

    return (
        db.query(models.RegistrationRequest)
        .order_by(models.RegistrationRequest.id.desc())
        .all()
    )


@router.post("/{request_id}/approve")
def approve_registration_request(
    request_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    require_admin(current_user)

    request = (
        db.query(models.RegistrationRequest)
        .filter(models.RegistrationRequest.id == request_id)
        .first()
    )

    if not request:
        raise HTTPException(status_code=404, detail="Request not found")

    if request.status != "pending":
        raise HTTPException(status_code=400, detail="Request already reviewed")

    existing_user = (
        db.query(models.User)
        .filter(models.User.email == request.email)
        .first()
    )

    if existing_user:
        raise HTTPException(status_code=409, detail="User already exists")

    new_user = models.User(
        email=request.email,
        full_name=request.full_name,
        role=request.role,
        password_hash=request.password_hash,
        status="active",
    )

    db.add(new_user)
    db.flush()

    created_patient_id = None

    if request.role == "patient":
        # Approval creates both the user account and the linked patient profile.
        # Initial assignment rows keep new patients on the same access model as
        # migrated existing patients.
        primary_doctor_id = get_default_active_user_id(db, "doctor")

        if primary_doctor_id is None:
            raise HTTPException(
                status_code=400,
                detail="Add an active doctor before approving patient access.",
            )

        patient = models.Patient(
            user_id=new_user.id,
            primary_doctor_id=primary_doctor_id,
            assigned_nurse_id=get_default_active_user_id(db, "nurse"),
            name=request.full_name,
            age=request.age or 18,
            condition=request.conditions or "General Monitoring",
            risk_level="Low",
            last_checkup=datetime.now().date().isoformat(),
        )

        db.add(patient)
        db.flush()

        created_patient_id = patient.id

        db.add(
            models.PatientStaffAssignment(
                patient_id=patient.id,
                staff_user_id=primary_doctor_id,
                role="doctor",
                status="active",
                assigned_at=datetime.now().isoformat(timespec="seconds"),
                assigned_by_user_id=current_user.id,
            )
        )

        if patient.assigned_nurse_id is not None:
            db.add(
                models.PatientStaffAssignment(
                    patient_id=patient.id,
                    staff_user_id=patient.assigned_nurse_id,
                    role="nurse",
                    status="active",
                    assigned_at=datetime.now().isoformat(timespec="seconds"),
                    assigned_by_user_id=current_user.id,
                )
            )

        event = models.PatientEvent(
            patient_id=patient.id,
            event_type="Registration",
            title="Patient profile created",
            description=(
                f"Patient registered with conditions: "
                f"{request.conditions or 'General Monitoring'}. "
                f"Medication notes: {request.medication_notes or 'None'}. "
                f"Lifestyle notes: {request.lifestyle_notes or 'None'}."
            ),
            timestamp=datetime.now().isoformat(timespec="seconds"),
        )

        db.add(event)

    request.status = "approved"

    db.commit()
    db.refresh(new_user)

    create_notification(
        db,
        user_email=new_user.email,
        title="Registration approved",
        message="Your account has been approved. You can now use the platform.",
        notification_type="registration",
        link="/",
        related_entity="RegistrationRequest",
        related_entity_id=str(request.id),
    )
    db.commit()

    write_audit_log(
        db=db,
        action="APPROVE_REGISTRATION_REQUEST",
        entity="User",
        entity_id=str(new_user.id),
        user_email=current_user.email,
    )

    return {
        "message": "Registration request approved and user created",
        "user_id": new_user.id,
        "patient_id": created_patient_id,
    }


@router.post("/{request_id}/reject")
def reject_registration_request(
    request_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    require_admin(current_user)

    request = (
        db.query(models.RegistrationRequest)
        .filter(models.RegistrationRequest.id == request_id)
        .first()
    )

    if not request:
        raise HTTPException(status_code=404, detail="Request not found")

    if request.status != "pending":
        raise HTTPException(status_code=400, detail="Request already reviewed")

    request.status = "rejected"

    # Store a rejection notification against the request email even though no
    # user account exists; this preserves a workflow trail for the applicant.
    create_notification(
        db,
        user_email=request.email,
        title="Registration rejected",
        message="Your access request was rejected by an administrator.",
        notification_type="registration",
        link="/register",
        related_entity="RegistrationRequest",
        related_entity_id=str(request.id),
    )

    db.commit()

    write_audit_log(
        db=db,
        action="REJECT_REGISTRATION_REQUEST",
        entity="RegistrationRequest",
        entity_id=str(request.id),
        user_email=current_user.email,
    )

    return {"message": "Registration request rejected"}
